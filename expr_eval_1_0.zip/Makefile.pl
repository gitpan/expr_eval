use ExtUtils::MakeMaker;

WriteMakefile(
    'NAME'     => 'Math::ExprEval',
    'VERSION_FROM'  => "expr_eval.pm"
);
